package com.example.flashcards;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    DBHelper helper;
    LinearLayout root, content;
    boolean dark = false;
    int index = 0;
    boolean showTranslation = false;
    ArrayList<Word> words = new ArrayList<>();
    ArrayList<Word> quizWords = new ArrayList<>();
    int quizIndex = 0, quizCorrect = 0;

    static class Word {
        long id; String word, translation, example, language, category;
        int interval, learned;
        Word(long id, String w, String t, String e, String l, String c, int i, int learned) {
            this.id=id; word=w; translation=t; example=e; language=l; category=c; interval=i; this.learned=learned;
        }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        helper = new DBHelper(this);
        showHome();
    }

    int bg() { return dark ? Color.rgb(27,27,31) : Color.rgb(247,245,251); }
    int fg() { return dark ? Color.WHITE : Color.rgb(32,30,36); }

    void setup(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 18, 18, 18); root.setBackgroundColor(bg());
        setContentView(root);
        TextView heading = new TextView(this); heading.setText(title); heading.setTextSize(25);
        heading.setTextColor(fg()); heading.setGravity(Gravity.CENTER); heading.setPadding(0, 6, 0, 16);
        root.addView(heading, new LinearLayout.LayoutParams(-1, -2));
        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(0, 4, 0, 12);
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        Button home = button("⌂  Главное меню"); home.setOnClickListener(v -> showHome());
        root.addView(home, new LinearLayout.LayoutParams(-1, -2));
    }

    Button button(String text) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false);
        b.setTextSize(16); return b;
    }
    TextView label(String text, int size) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(fg());
        t.setPadding(4, 8, 4, 8); return t;
    }
    EditText edit(String hint) {
        EditText e = new EditText(this); e.setSingleLine(false); e.setHint(hint); e.setTextColor(fg());
        e.setHintTextColor(dark ? Color.LTGRAY : Color.GRAY); return e;
    }
    void addButton(String s, Runnable r) {
        Button b = button(s); b.setOnClickListener(v -> r.run());
        content.addView(b, new LinearLayout.LayoutParams(-1, -2));
    }
    void showHome() {
        setup("Словарь / Flashcards");
        int total = helper.count(false), learned = helper.count(true), due = helper.dueCount();
        content.addView(label("Запоминай слова с помощью карточек и интервального повторения.", 16));
        content.addView(label("Всего слов: " + total + "\nВыучено: " + learned +
                "\nК повторению сегодня: " + due + "\nПрогресс: " + (total==0?0:(learned*100/total)) + "%", 18));
        addButton("＋ Добавить слово", this::showAdd);
        addButton("📚 Мои слова", this::showList);
        addButton("🃏 Карточки для повторения", this::showCards);
        addButton("📝 Тест на 4 варианта", this::startQuiz);
        addButton(dark ? "☀ Светлая тема" : "🌙 Темная тема", () -> { dark = !dark; showHome(); });
    }

    void showAdd() {
        setup("Добавить слово");
        EditText w=edit("Слово (например, journey)"), t=edit("Перевод"), e=edit("Пример использования"),
                l=edit("Язык (английский, французский...)"), c=edit("Тема (Путешествия, Работа...)");
        content.addView(w); content.addView(t); content.addView(e); content.addView(l); content.addView(c);
        addButton("Сохранить слово", () -> {
            String sw=w.getText().toString().trim(), st=t.getText().toString().trim();
            if (sw.isEmpty() || st.isEmpty()) { toast("Введите слово и перевод"); return; }
            ContentValues cv=new ContentValues(); cv.put("word",sw); cv.put("translation",st);
            cv.put("example",e.getText().toString().trim());
            cv.put("language",l.getText().toString().trim().isEmpty()?"Английский":l.getText().toString().trim());
            cv.put("category",c.getText().toString().trim().isEmpty()?"Без темы":c.getText().toString().trim());
            cv.put("interval",1); cv.put("learned",0); cv.put("next_review",System.currentTimeMillis());
            helper.getWritableDatabase().insert("words",null,cv);
            toast("Слово сохранено"); showHome();
        });
    }

    void showList() {
        setup("Мои слова");
        words=helper.all();
        if(words.isEmpty()) { content.addView(label("Пока нет слов. Добавьте первое слово.",17)); return; }
        for(Word x: words) {
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(12,8,12,8); card.setBackgroundColor(dark?Color.rgb(45,45,50):Color.WHITE);
            TextView tx=label(x.word+" — "+x.translation,18); card.addView(tx);
            card.addView(label("Язык: "+x.language+" • Тема: "+x.category+"\n"+(x.example.isEmpty()?"": "Пример: "+x.example),14));
            Button del=button("Удалить"); del.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setMessage("Удалить слово «"+x.word+"»?")
                    .setNegativeButton("Отмена",null).setPositiveButton("Удалить",(d,which)->{
                        helper.getWritableDatabase().delete("words","id=?",new String[]{String.valueOf(x.id)}); showList();
                    }).show());
            card.addView(del); content.addView(card);
        }
    }

    void showCards() {
        setup("Карточки");
        words=helper.due();
        if(words.isEmpty()) words=helper.all();
        if(words.isEmpty()) { content.addView(label("Сначала добавьте несколько слов.",17)); return; }
        index=Math.min(index,words.size()-1); showTranslation=false;
        renderCard();
    }
    void renderCard() {
        content.removeAllViews();
        if(words.isEmpty()) return;
        Word x=words.get(index % words.size());
        content.addView(label("Карточка "+(index%words.size()+1)+" из "+words.size(),14));
        TextView face=label(showTranslation?x.translation:x.word,30); face.setGravity(Gravity.CENTER);
        face.setPadding(10,50,10,50); content.addView(face);
        if(showTranslation && !x.example.isEmpty()) content.addView(label("Пример: "+x.example,16));
        addButton(showTranslation?"Показать слово":"Показать перевод",()->{showTranslation=!showTranslation;renderCard();});
        addButton("Знаю ✓",()->{rate(x,true); index++; if(index>=words.size()) index=0; showCards();});
        addButton("Не знаю ✗",()->{rate(x,false); index++; if(index>=words.size()) index=0; showCards();});
        addButton("Следующая →",()->{index=(index+1)%words.size();showTranslation=false;renderCard();});
    }
    void rate(Word x, boolean known) {
        int interval = known ? Math.min(x.interval==1?3:x.interval==3?7:x.interval==7?14:30,30) : 1;
        long next=System.currentTimeMillis()+(known?interval:1)*24L*60*60*1000;
        ContentValues cv=new ContentValues(); cv.put("interval",interval); cv.put("learned",known?1:0); cv.put("next_review",next);
        helper.getWritableDatabase().update("words",cv,"id=?",new String[]{String.valueOf(x.id)});
        toast(known?"Отлично! Следующее повторение через "+interval+" дн.":"Повторите это слово завтра.");
    }

    void startQuiz() {
        quizWords=helper.all(); if(quizWords.size()<2){toast("Для теста добавьте минимум 2 слова");return;}
        Collections.shuffle(quizWords); quizIndex=0; quizCorrect=0; showQuizQuestion();
    }
    void showQuizQuestion() {
        setup("Тест");
        if(quizIndex>=Math.min(10,quizWords.size())) {
            content.addView(label("Тест завершён!\nПравильных ответов: "+quizCorrect+" из "+Math.min(10,quizWords.size())+
                    "\nРезультат: "+(quizCorrect*100/Math.min(10,quizWords.size()))+"%",22));
            addButton("Пройти ещё раз",this::startQuiz); return;
        }
        Word q=quizWords.get(quizIndex);
        content.addView(label("Вопрос "+(quizIndex+1)+" из "+Math.min(10,quizWords.size()),15));
        content.addView(label("Выберите перевод слова:\n\n"+q.word,25));
        ArrayList<Word> options=new ArrayList<>(); options.add(q);
        for(Word x:helper.all()) if(x.id!=q.id && options.size()<4) options.add(x);
        Collections.shuffle(options);
        for(Word x:options) {
            Button b=button(x.translation); b.setOnClickListener(v->{
                if(x.id==q.id){quizCorrect++; rate(q,true); toast("Верно!");} else {rate(q,false);toast("Неверно. Перевод: "+q.translation);}
                quizIndex++; showQuizQuestion();
            }); content.addView(b);
        }
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    static class DBHelper extends SQLiteOpenHelper {
        DBHelper(Activity a){super(a,"flashcards.db",null,1);}
        public void onCreate(SQLiteDatabase db){
            db.execSQL("CREATE TABLE words (id INTEGER PRIMARY KEY AUTOINCREMENT, word TEXT NOT NULL, translation TEXT NOT NULL, example TEXT, language TEXT, category TEXT, interval INTEGER DEFAULT 1, learned INTEGER DEFAULT 0, next_review INTEGER)");
        }
        public void onUpgrade(SQLiteDatabase db,int oldV,int newV){}
        int count(boolean learned){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM words"+(learned?" WHERE learned=1":""),null);c.moveToFirst();int n=c.getInt(0);c.close();return n;}
        int dueCount(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM words WHERE next_review<=?",new String[]{String.valueOf(System.currentTimeMillis())});c.moveToFirst();int n=c.getInt(0);c.close();return n;}
        ArrayList<Word> all(){return query("SELECT * FROM words ORDER BY id DESC",null);}
        ArrayList<Word> due(){return query("SELECT * FROM words WHERE next_review<=? ORDER BY next_review",new String[]{String.valueOf(System.currentTimeMillis())});}
        ArrayList<Word> query(String sql,String[] args){
            ArrayList<Word> out=new ArrayList<>(); Cursor c=getReadableDatabase().rawQuery(sql,args);
            while(c.moveToNext()) out.add(new Word(c.getLong(0),c.getString(1),c.getString(2),c.getString(3)==null?"":c.getString(3),
                    c.getString(4)==null?"":c.getString(4),c.getString(5)==null?"":c.getString(5),c.getInt(6),c.getInt(7)));
            c.close();return out;
        }
    }
}
